import os
import hashlib
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import mimetypes
import requests
import csv
from datetime import datetime

# === CONFIGURATION ===
VIRUSTOTAL_API_KEY = ""  # <-- Insert your VirusTotal API key here

# === GLOBALS ===
history = []
dark_mode = True

# === HASH FUNCTIONS ===
def calculate_hash(file_path, algo="sha256"):
    hash_func = getattr(hashlib, algo)()
    try:
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_func.update(chunk)
        return hash_func.hexdigest()
    except Exception as e:
        return f"An error occurred: {str(e)}"

# === FILE METADATA ===
def get_file_metadata(file_path):
    try:
        size = os.path.getsize(file_path)
        file_type, _ = mimetypes.guess_type(file_path)
        return {
            "name": os.path.basename(file_path),
            "size": f"{size / 1024:.2f} KB",
            "type": file_type or "Unknown"
        }
    except:
        return {"name": "?", "size": "?", "type": "?"}

# === VIRUSTOTAL LOOKUP ===
def check_virustotal(hash_value):
    if not VIRUSTOTAL_API_KEY:
        return "🔒 No VirusTotal API key provided."
    url = f"https://www.virustotal.com/api/v3/files/{hash_value}"
    headers = {"x-apikey": VIRUSTOTAL_API_KEY}
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            data = response.json()
            stats = data.get("data", {}).get("attributes", {}).get("last_analysis_stats", {})
            return f"🦠 VirusTotal Stats: Clean: {stats.get('harmless', '?')} | Malicious: {stats.get('malicious', '?')} | Suspicious: {stats.get('suspicious', '?')}"
        else:
            return f"❌ VirusTotal lookup failed ({response.status_code})"
    except Exception as e:
        return f"❌ VirusTotal error: {str(e)}"

# === GUI FUNCTIONS ===
def browse_file():
    file_paths = filedialog.askopenfilenames()
    if file_paths:
        file_entry.delete(0, tk.END)
        file_entry.insert(0, ", ".join(file_paths))

def verify_hash():
    file_paths = file_entry.get().split(", ")
    original_hash = hash_entry.get().strip()
    algo = hash_algo.get()
    result_text = []
    progress_label.config(text="Processing...")
    root.update()

    for file_path in file_paths:
        if not os.path.isfile(file_path):
            continue
        meta = get_file_metadata(file_path)
        calculated_hash = calculate_hash(file_path, algo=algo)
        result = [
            f"📄 File: {meta['name']}",
            f"📦 Size: {meta['size']}",
            f"📁 Type: {meta['type']}",
            f"🔐 Algorithm: {algo.upper()}",
            f"🔢 Hash: {calculated_hash}"
        ]
        match = ""
        if original_hash:
            if calculated_hash.lower() == original_hash.lower():
                match = "✅ Hash matches! File is valid."
            else:
                match = "❌ Hash does not match! File may be altered."
            result.append(match)
        else:
            match = "⚠️ No original hash provided."
            result.append(match)

        vt_result = check_virustotal(calculated_hash)
        result.append(vt_result)

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        history.append([timestamp, meta['name'], meta['size'], meta['type'], algo, calculated_hash, match])
        result_text.extend(result + ["\n"])

    progress_label.config(text="Done.")
    display_result("\n".join(result_text))


def display_result(text):
    result_display.config(state=tk.NORMAL)
    result_display.delete(1.0, tk.END)
    result_display.insert(tk.END, text)
    result_display.config(state=tk.DISABLED)


def save_report():
    report = result_display.get("1.0", tk.END).strip()
    if not report:
        messagebox.showwarning("Error", "No report to save.")
        return
    save_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
    if save_path:
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                f.write(report)
            messagebox.showinfo("Report Saved", f"Report saved to:\n{save_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save report: {str(e)}")


def export_csv():
    if not history:
        messagebox.showwarning("Error", "No data to export.")
        return
    save_path = filedialog.asksaveasfilename(defaultextension=".csv",
                                             filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
    if save_path:
        try:
            with open(save_path, "w", newline="", encoding="utf-8") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(["Timestamp", "Filename", "Size", "Type", "Algorithm", "Hash", "Result"])
                writer.writerows(history)
            messagebox.showinfo("CSV Exported", f"Data exported to:\n{save_path}")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to export CSV: {str(e)}")


def copy_to_clipboard():
    report = result_display.get("1.0", tk.END).strip()
    root.clipboard_clear()
    root.clipboard_append(report)
    root.update()
    messagebox.showinfo("Copied", "Report copied to clipboard!")


def clear_all():
    file_entry.delete(0, tk.END)
    hash_entry.delete(0, tk.END)
    result_display.config(state=tk.NORMAL)
    result_display.delete("1.0", tk.END)
    result_display.config(state=tk.DISABLED)
    progress_label.config(text="")


def toggle_theme():
    global dark_mode
    dark_mode = not dark_mode

    bg = "#1e1e1e" if dark_mode else "#ffffff"
    fg = "#ffffff" if dark_mode else "#000000"
    entry_bg = "#2a2a2a" if dark_mode else "#f0f0f0"
    button_bg = "#333333" if dark_mode else "#dddddd"
    result_fg = "lime" if dark_mode else "black"

    root.configure(bg=bg)

    def customize_widget_colors(widget):
        if isinstance(widget, (tk.Label, tk.Frame)):
            widget.configure(bg=bg, fg=fg)
        elif isinstance(widget, tk.Text):
            widget.configure(bg=entry_bg, fg=result_fg)
        elif isinstance(widget, tk.Entry):
            widget.configure(bg=entry_bg, fg=fg, insertbackground=fg)
        elif isinstance(widget, tk.Button):
            widget.configure(bg=button_bg, fg=fg, activebackground=bg, activeforeground=fg)
        elif isinstance(widget, tk.OptionMenu):
            widget.configure(bg=button_bg, fg=fg, activebackground=bg, activeforeground=fg)
            menu = widget.nametowidget(widget.menuname)
            menu.configure(bg=bg, fg=fg)
        for child in widget.winfo_children():
            customize_widget_colors(child)

    customize_widget_colors(root)

# === GUI SETUP ===
root = tk.Tk()
root.title("🧰 File Hash Verifier")
root.geometry("750x600")
root.configure(bg="#1e1e1e")

font_label = ("Arial", 12)
font_entry = ("Arial", 12)
font_button = ("Arial", 12, "bold")

# File selection
file_label = tk.Label(root, text="📂 Select File(s):", font=font_label, bg="#1e1e1e", fg="#ffffff")
file_label.pack(pady=5)
file_frame = tk.Frame(root, bg="#1e1e1e")
file_frame.pack()
file_entry = tk.Entry(file_frame, width=55, font=font_entry)
file_entry.pack(side=tk.LEFT, padx=5, pady=5)
browse_button = tk.Button(file_frame, text="Browse", command=browse_file, font=font_button, bg="#007bff", fg="#ffffff")
browse_button.pack(side=tk.LEFT, padx=5)

# Hash type
algo_label = tk.Label(root, text="Select Hash Type:", bg="#1e1e1e", fg="white", font=font_label)
algo_label.pack(pady=5)
hash_algo = tk.StringVar(value="sha256")
hash_dropdown = tk.OptionMenu(root, hash_algo, "sha256", "sha1", "md5")
hash_dropdown.config(font=font_label)
hash_dropdown.pack(pady=5)

# Original hash entry
tk.Label(root, text="Original Hash (optional):", bg="#1e1e1e", fg="white", font=font_label).pack(pady=5)
hash_entry = tk.Entry(root, width=60, font=font_entry)
hash_entry.pack(pady=5)

# Buttons
button_frame = tk.Frame(root, bg="#1e1e1e")
button_frame.pack(pady=10)
toggle_btn = tk.Button(button_frame, text="Verify", font=font_button, command=verify_hash).pack(side=tk.LEFT, padx=5)
toggle_btn = tk.Button(button_frame, text="Copy Report", font=font_button, command=copy_to_clipboard).pack(side=tk.LEFT, padx=5)
toggle_btn = tk.Button(button_frame, text="Save as TXT", font=font_button, command=save_report).pack(side=tk.LEFT, padx=5)
toggle_btn = tk.Button(button_frame, text="Export CSV", font=font_button, command=export_csv).pack(side=tk.LEFT, padx=5)
toggle_btn = tk.Button(button_frame, text="Clear All", font=font_button, command=clear_all).pack(side=tk.LEFT, padx=5)
toggle_btn = tk.Button(button_frame, text="Toggle Theme", font=font_button, command=toggle_theme).pack(side=tk.LEFT, padx=5)

  
# Result display
progress_label = tk.Label(root, text="", font=("Arial", 10), bg="#1e1e1e", fg="lime")
progress_label.pack()
result_display = tk.Text(root, width=85, height=16, wrap="word", font=("Courier", 10), bg="#2a2a2a", fg="lime", state='disabled')
result_display.pack(pady=10)

root.mainloop()
