# 🧪 File Hash Verifier2

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![GUI](https://img.shields.io/badge/GUI-Tkinter-informational)
![Security](https://img.shields.io/badge/Feature-Hash%20Validation-green)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---
🧰 File Hash Verifier
A Python GUI tool to compute and verify cryptographic file hashes (SHA-256, SHA-1, MD5), enriched with VirusTotal checks, file metadata, and exportable reports. Useful for digital forensics, malware analysis, and file integrity verification.

🔍 Features
✅ Multi-hash support: SHA-256, SHA-1, MD5
✅ VirusTotal integration: Check file hash against known malware databases
✅ File metadata: Displays file name, size, type
✅ Batch mode: Select and process multiple files at once
✅ Copy to clipboard: Copy results or hashes instantly
✅ Dark/Light theme toggle: Customizable interface
✅ Progress indicator: Visual feedback during long operations
✅ Clear All Fields: Reset inputs and outputs with one click
✅ Export reports: Save results in .txt or .csv formats
✅ History panel: View all previously verified files in a session

🚀 Installation
🐍 Prerequisites
Python 3.9 or above

pip (Python package manager)

📦 Install Dependencies
bash

pip install requests
✅ No external Tkinter DnD dependencies required!

💡 How to Use
Launch the app:

bash

python File_Hash_Verifier.py
Click "Browse" to select a file or multiple files.

Choose a hash algorithm (SHA256, SHA1, MD5).

(Optional) Enter a known original hash to compare.

Click "Verify" to compute hash and check VirusTotal.

View results and:

Copy them

Export to TXT/CSV

Track in history panel

📁 Folder Structure

📁 File_Hash_Verifier/
├── File_Hash_Verifier_2.py
├── README.md
├── screenshots/
│   └── demo.png
└── reports/
    ├── report.txt
    └── report.csv

📜 License
This project is licensed under the MIT License.
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

🛠️ TODO / Ideas
Add support for drag-and-drop (optional plugin)

Add ability to upload files to VirusTotal

Save persistent history across sessions

Auto-generate hash QR codes

🙌 Acknowledgments
VirusTotal API

Python Tkinter Docs

Hashing by hashlib | File type by mimetypes
